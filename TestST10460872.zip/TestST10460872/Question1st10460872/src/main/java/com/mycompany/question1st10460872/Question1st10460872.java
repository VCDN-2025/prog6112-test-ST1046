/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.question1st10460872;

//importing the scanner
import java.util.Scanner;

public class Question1st10460872 {

    public static void main(String[] args) {
        
        //(Adnan, 2025)
        Scanner scan= new Scanner(System.in);
        //1D aray of the runners as well as the stadium all hardcoded
        String[] runner ={"Jacques Kallis", "Hashim Amla", "AB De Villiers" };
        String[] stadium = {"Kigsmead", "St Georges", "Wanderers"};
        //2D Array created to store the actual inputs per stadium and runner
        int[][] runs = new int[stadium.length][runner.length];
        
        //Outer forloop with inner forloop to identify and later used to capture the relavant data 
        for(int i = 0; i < stadium.length; i++)
            {
            for (int j = 0; j< runner.length; j++)
            {
        System.out.print("Enter the number of runs scored by " + runner[j]+ " at " + stadium[i] + ":");
        runs[i][j] = scan.nextInt();
    }
}
        
        //Print the 2D array
        System.out.println("\n ---------------------------------");
        System.out.print("\t\tRUNS SCORED REPORT: ");
        System.out.println("---------------------------------");
        
        System.out.print("\t\tStadium");
        
        for(String r : runner) {
            System.out.print(r +"\t");
        }
            System.out.println();
            
            for(int i = 0;i< stadium.length; i++){
                System.out.print(stadium[i] + "\t");
                for (int j = 0; j< runner.length; j++){
                    System.out.print(runs[i][j] + "\t\t");
                }
                System.out.println();
            }
      //calculating and printing totals runs in each stadium
      //(Classwork, 2025)
         System.out.println("---------------------------------");
         System.out.println("\nTOTAL RUNS PER STADIUM:");
         System.out.println("---------------------------------");
          
         for (int i =0; i< stadium.length; i++){
            int stadiumTotal = 0;
            for (int j=0; j<runner.length; j++){
                stadiumTotal += runs[i][j];
            }
             System.out.println(stadium[i] + ": " + stadiumTotal);
         }
         //calculating and printing totals of wich is the highest runs in which stadium
         //(Adnan, 2025)
         System.out.println("---------------------------------");
         System.out.println("\nSTADIUM WITH THE MOST RUNS:");
         System.out.println("---------------------------------");
         
         int maxStadiumRuns = 0;
         int maxStadiumIndex =0;
         for(int i =0; i < stadium.length; i++){
             int stadiumTotal = 0;
             for (int j = 0; j <runner.length; j++){
                 stadiumTotal += runs[i][j];
               
             }
             if (stadiumTotal > maxStadiumRuns){
                 maxStadiumRuns = stadiumTotal;
                 maxStadiumIndex = i;
             }
         }
         System.out.println(stadium[maxStadiumIndex] + " has the highest runs");
    }
    
    
    }
//REFERENCE LIST: 
// Classwork and Lectures adapted into project code.
// Adnan. Y. 2025. Github Repository. Memo_Mock_Test. Avialable on github. [Accessed 29 Septemeber 2025]
