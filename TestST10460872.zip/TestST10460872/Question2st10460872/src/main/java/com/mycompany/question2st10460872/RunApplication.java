/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.question2st10460872;
import java.util.Scanner;
/**
 *
 * @author lab_services_student
 */

// 4. Application Runner
public class RunApplication {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);

        // Prompt user input
        System.out.print("Enter the cricketer name: ");
        String batsman = scan.nextLine();

        System.out.print("Enter the stadium: ");
        String stadium = scan.nextLine();

        System.out.print("Enter the total runs scored by " + batsman + " at " + stadium + ": ");
        int runsScored = scan.nextInt();

        // Create object
        CricketRunsScored cr = new CricketRunsScored(batsman, stadium, runsScored);

        // Print report
        cr.printReport();
    }
}

