/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.question2st10460872;
import java.util.Scanner;
/**
 *
 * @author lab_services_student
 */
public class Question2st10460872 {



// 1. Interface
public interface ICricket {
    String getBatsman();
    String getStadium();
    int getRunsScored();
}
}
